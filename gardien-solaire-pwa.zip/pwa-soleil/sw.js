const CACHE_NAME = 'gardien-solaire-v1';
const ASSETS = [
  '/index.html',
  '/manifest.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png'
];

// Install: cache assets
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE_NAME).then(c => c.addAll(ASSETS))
  );
  self.skipWaiting();
});

// Activate: clean old caches
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Fetch: network first, fallback to cache
self.addEventListener('fetch', e => {
  if (e.request.url.includes('api.open-meteo.com') ||
      e.request.url.includes('nominatim.openstreetmap.org')) {
    // API calls: network only
    return;
  }
  e.respondWith(
    fetch(e.request).catch(() => caches.match(e.request))
  );
});

// Push notifications
self.addEventListener('push', e => {
  const data = e.data?.json() || {};
  e.waitUntil(
    self.registration.showNotification(data.title || '☀️ Gardien Solaire', {
      body: data.body || 'Vérifiez votre indice UV du jour !',
      icon: '/icons/icon-192.png',
      badge: '/icons/icon-192.png',
      tag: 'uv-reminder',
      renotify: true,
      data: { url: '/' },
      actions: [
        { action: 'open', title: '📊 Voir l\'indice UV' },
        { action: 'dismiss', title: 'Plus tard' }
      ]
    })
  );
});

// Notification click
self.addEventListener('notificationclick', e => {
  e.notification.close();
  if (e.action === 'dismiss') return;
  e.waitUntil(
    clients.matchAll({ type: 'window' }).then(list => {
      if (list.length) return list[0].focus();
      return clients.openWindow('/');
    })
  );
});

// Background sync for daily UV check
self.addEventListener('sync', e => {
  if (e.tag === 'daily-uv-check') {
    e.waitUntil(checkAndNotify());
  }
});

async function checkAndNotify() {
  try {
    const stored = await getStoredLocation();
    if (!stored) return;
    const r = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${stored.lat}&longitude=${stored.lon}&current=uv_index&timezone=auto`
    );
    const d = await r.json();
    const uv = Math.round(d.current.uv_index);
    if (uv > 3) {
      await self.registration.showNotification('☀️ Attention UV élevés !', {
        body: `Indice UV ${uv} aujourd'hui à ${stored.city}. Pensez à vous protéger !`,
        icon: '/icons/icon-192.png',
        tag: 'uv-reminder',
        renotify: true
      });
    }
  } catch(e) { /* silent */ }
}

function getStoredLocation() {
  return new Promise(resolve => {
    // Read from IndexedDB or message clients
    resolve(null);
  });
}

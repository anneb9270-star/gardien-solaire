# ☀️ Gardien Solaire — Guide de déploiement PWA

## Structure des fichiers
```
gardien-solaire/
├── index.html       ← Application principale
├── manifest.json    ← Manifeste PWA
├── sw.js            ← Service Worker (cache + notifications)
└── icons/
    ├── icon-192.png
    └── icon-512.png
```

---

## 🚀 Option 1 — Netlify Drop (GRATUIT, 2 minutes)

1. Allez sur **https://app.netlify.com/drop**
2. Glissez-déposez le dossier `gardien-solaire` entier
3. Netlify génère une URL type `https://random-name.netlify.app`
4. ✅ Votre PWA est en ligne !

**Sur iPhone :**
- Ouvrez l'URL dans Safari
- Appuyez sur ⬆ Partager → "Sur l'écran d'accueil"
- L'icône ☀️ apparaît comme une vraie app !

**Sur Android :**
- Ouvrez l'URL dans Chrome
- Une bannière "Installer" apparaît automatiquement
- Ou : menu ⋮ → "Ajouter à l'écran d'accueil"

---

## 🚀 Option 2 — GitHub Pages (GRATUIT, permanent)

1. Créez un compte GitHub sur https://github.com
2. Nouveau dépôt → uploadez les fichiers + dossier icons/
3. Settings → Pages → Source: main branch → Save
4. URL : https://votre-pseudo.github.io/gardien-solaire

---

## ✨ Fonctionnalités PWA actives

- Installation sur l'écran d'accueil (icône native)
- Mode plein écran sans barre de navigateur
- Fonctionne hors-ligne (pages en cache)
- Notifications push matinales si UV > 3
- Rappels UV personnalisables (7h, 8h, 9h, ou heure custom)
- Sauvegarde ville + phototype entre les sessions
- Badge hors-ligne si pas de connexion

*Données météo Open-Meteo · Recommandations OMS*
